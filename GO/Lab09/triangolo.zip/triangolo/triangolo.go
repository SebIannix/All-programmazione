package triangolo

import (
	"fmt"
	)

type triangolo struct {
	base, altezza int
}

func NewTriangolo() *triangolo {

	t := new(triangolo)

	return t		
}

func Area(t *triangolo) float64 {

	return float64(t.base * t.altezza) / 2

}

func SetAltezza(t *triangolo, h int) {

	t.altezza = h 

}

func SetBase(t *triangolo, b int) {

	t.base = b

}

func String(t *triangolo) string {

	s := fmt.Sprintf("Triangolo con base e altezza rispettivamente pari a %d e %d.\nL'area del triangolo è pari a %.3f", t.base, t.altezza, Area(t));
	return s  
}

