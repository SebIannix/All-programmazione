package punto

import (
	"fmt"
)

// Contatore dei punti creati.
// Questo contatore viene incrementato solo quando si usa la funzione NuovoPunto
// per creare un nuovo punto
var nextID uint64 = 0

// Struttura per memorizzre le coordinate x e y di un punto su un piano
// cartesiano a due dimensioni.
type Punto struct {
	id   uint64
	x, y float64
}

// Crea un nuovo punto restituendone il puntatore.
// Le coordinate x e y del punto sono inizializzate con i
// valori passati come parametri della funzione
func NuovoPunto(x, y float64) *Punto {
	p := &Punto{nextID, x, y}
	nextID++
	return p
}

// Restituisce l'identificativo di un punto
func (p *Punto) ID() uint64 {
	return p.id
}

// Restituisce la coordinata x di un punto
func (p *Punto) X() float64 {
	return p.x
}

// Restituisce la coordinata y di un punto
func (p *Punto) Y() float64 {
	return p.y
}

// Imposta la coordinata x di un punto
func (p *Punto) SetX(x float64) {
	p.x = x
}

// Imposta la coordinata x di un punto
func (p *Punto) SetY(y float64) {
	p.y = y
}

// Restituisce una stringa che rappresenta il punto
func (p *Punto) String() string {
	return fmt.Sprintf("P(id = %v, X = %6.3f, Y = %6.3f)",  p.id, p.x, p.y);
}
