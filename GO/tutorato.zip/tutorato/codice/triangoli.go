package main

import "fmt"

func main() {
	var a, b, c float64

	fmt.Println("Inserisci tre numeri separati da spazi:")
	fmt.Scanln(&a, &b, &c)
	if a == b && a == c {
		fmt.Println("Il triangolo e` ___________________")
	} else if a == b || a == c || b == c {
		fmt.Println("Il triangolo e` ___________________")
	} else {
		fmt.Println("Il triangolo e` ___________________")
	}
}
 
